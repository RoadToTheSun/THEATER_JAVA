create definer = root@localhost trigger ADD_PRICE_TRIGGER
    before insert
    on ticket
    for each row
BEGIN
SET NEW.CUR_PRICE = if(NEW.place between 0 and 100, 500, 1000);
END;

