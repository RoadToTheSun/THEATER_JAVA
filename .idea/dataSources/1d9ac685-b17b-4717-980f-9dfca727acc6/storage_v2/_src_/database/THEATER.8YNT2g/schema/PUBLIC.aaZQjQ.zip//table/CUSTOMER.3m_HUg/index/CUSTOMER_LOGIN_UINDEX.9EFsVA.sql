create unique index CUSTOMER_LOGIN_UINDEX
    on CUSTOMER (LOGIN);

