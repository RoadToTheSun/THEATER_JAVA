create unique index PRIMARY_KEY_5
    on CUSTOMER (ID);

