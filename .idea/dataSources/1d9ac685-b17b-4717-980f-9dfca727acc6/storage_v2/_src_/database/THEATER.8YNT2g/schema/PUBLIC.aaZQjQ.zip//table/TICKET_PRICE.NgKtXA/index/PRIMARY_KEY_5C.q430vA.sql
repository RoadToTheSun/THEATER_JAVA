create unique index PRIMARY_KEY_5C
    on TICKET_PRICE (ID);

