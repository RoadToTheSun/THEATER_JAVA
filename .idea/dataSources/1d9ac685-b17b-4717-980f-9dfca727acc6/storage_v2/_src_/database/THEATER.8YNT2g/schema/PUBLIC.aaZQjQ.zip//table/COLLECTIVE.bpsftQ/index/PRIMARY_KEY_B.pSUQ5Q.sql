create unique index PRIMARY_KEY_B
    on COLLECTIVE (DIRECTION);

