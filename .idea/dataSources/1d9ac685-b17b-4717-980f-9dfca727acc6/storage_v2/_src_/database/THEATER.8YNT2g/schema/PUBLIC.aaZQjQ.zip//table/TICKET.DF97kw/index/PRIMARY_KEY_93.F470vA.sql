create unique index PRIMARY_KEY_93
    on TICKET (NUMBER);

