create index "TICKET___session_id_INDEX_9"
    on TICKET (SESSION_ID);

