create index NAME__INDEX
    on SPECTACLE (NAME);

